
%%%%%%%%%%%%%%%%%%% SET PARAMETERS FOR THE CODE  %%%%%%%%%%%%%%%%%%%%%%%%%
easypart=dir('/Volumes/Seagate_Drive/data_jason/easy/*.mat');
hardpart=dir('/Volumes/Seagate_Drive/data_jason/hard/*.mat');

% Frontal ELECTRODES
%'C14' 'C13' 'C12' 'C21' 'C22' 'C6' 'C5' 'C15' 'C20' 'C4'
%
% Parietal Electrodes
% 'C10' 'A1' 'A2' 'C24' 'C8' 'C9' 'C25' 'C3' 'C19' 'A18'
%
% OCCIPITAL ELECTRODES
%'A13' 'A14' 'A15' 'A24' 'A22' 'A6' 'A7' 'A8' 'A23'
electrodes={'A13' 'A14' 'A15' 'A24' 'A22' 'A6' 'A7' 'A8' 'A23'};
n_permutes = 5000;
alpha_level=0.05;
nTimepoints=1536;
npart=12;
erp=zeros(nTimepoints,npart);
raw_eeg=zeros(nTimepoints,2*npart);
length_win=[51,102 ,128, 154, 205, 256];
counter=1;


%%%%%%%%%%%% READ DATA AND COMPURTE ERP  %%%%%%%%%%%%%%%%%%%
%%%%%  EASY  %%%%%%
cd('/Volumes/Seagate_Drive/data_jason/easy');
for i=1:npart
    load(easypart(i,1).name);
    disp(easypart(i,1).name);
    counter_elec=1;
for k = 1:length(electrodes)
    if ~isempty(find(strcmp(easy_cond.chan_labels, electrodes(1,k))))
        use_elec(1,counter_elec)=find(strcmp(easy_cond.chan_labels, electrodes(1,k)));
        counter_elec=counter_elec+1;
    end
end
    temp=easy_cond.eeg_data(use_elec,:,:);
    temp_1=squeeze(mean(mean(temp,3),1))';
    raw_eeg(:,i)=temp_1;

end

%%%%%%% HARD %%%%%%%%%%
cd('/Volumes/Seagate_Drive/data_jason/hard');
for i=1:npart
    load(hardpart(i,1).name);
    disp(hardpart(i,1).name);
    counter_elec=1;
for k = 1:length(electrodes)
    if ~isempty(find(strcmp(hard_cond.chan_labels, electrodes(1,k))))
        use_elec(1,counter_elec)=find(strcmp(hard_cond.chan_labels, electrodes(1,k)));
        counter_elec=counter_elec+1;
    end
end
    temp=hard_cond.eeg_data(use_elec,:,:);
    temp_1=squeeze(mean(mean(temp,3),1))';
    raw_eeg(:,i+npart)=temp_1;

end

%%% Save data in appropriate variable names
tftimes=easy_cond.time_ms;
Time=tftimes;
erp=raw_eeg;
raw_eeg_orig=raw_eeg;

%% PLOT DIFFERENCE WAVES TO VERIFY
figure;
% blue is cued and orange is not cued
plot(-1*mean(erp(:,1:12),2)');
hold on;
plot(-1*mean(erp(:,13:24),2)');



%%%% SET UP OF LARGE FOR LOOP TO ITERATE THROUGH ALL BASELINE CORRECTION
%%%% WINDOW LENGTHS AS SPECIFIED ABOVE
for j=1:length(length_win)

w=length_win(j);
L = 513;

for k1 = 257:L-w+1
    %%sliding windows for baseline correction
baseline=k1:k1+w-1;
raw_eeg=raw_eeg_orig-mean(raw_eeg_orig(baseline,:));
erp=raw_eeg;

easyoverall_erp(counter,:)=-1*mean(erp(:,1:12),2)';
hardoverall_erp(counter,:)=-1*mean(erp(:,13:24),2)';

%%%% SET UP FOR PERMUTATIONS 
real_condition_mapping = [repmat(-1,1,npart), repmat(1,1,npart)];
% compute paired t-test for real data
dif = sum(erp(:,real_condition_mapping==-1)-erp(:,real_condition_mapping==1),2);
tnum = dif./sum(real_condition_mapping==-1);
sqdiff=sum((erp(:,real_condition_mapping==-1)-erp(:,real_condition_mapping==1).^2),2);
tdenom_n = sqdiff- ((dif.^2)./sum(real_condition_mapping==-1));
tdenom_d = (sum(real_condition_mapping==-1)-1)*sum(real_condition_mapping==-1);
tdenom = abs(sqrt(tdenom_n./tdenom_d));
real_t = tnum./tdenom;

% initialize null hypothesis matrices
permuted_tvals  = zeros(n_permutes,nTimepoints);

% generate null hypothesis parameter distributions
for permi = 1:n_permutes
    per=sign(randn(npart,1));
    fake_condition_mapping = [per; -per];
    
    % compute t-map of null hypothesis
    dif = sum(erp(:,fake_condition_mapping==-1)-erp(:,fake_condition_mapping==1),2);
    tnum = dif./sum(fake_condition_mapping==-1);
    sqdiff=sum((erp(:,fake_condition_mapping==-1)-erp(:,fake_condition_mapping==1).^2),2);
    tdenom_n = sqdiff- ((dif.^2)./sum(fake_condition_mapping==-1));
    tdenom_d = (sum(fake_condition_mapping==-1)-1)*sum(fake_condition_mapping==-1);
    tdenom = abs(sqrt(tdenom_n./tdenom_d));
    tmap = tnum./tdenom;
    
    % save all permuted values
    permuted_tvals(permi,:) = tmap;

end

%% GET PERCENTILE OF CRITICAL T VALUE TO COMPARE
crit_t=prctile(permuted_tvals,100*(1-(alpha_level/2)));
t_test= abs(real_t')>crit_t;
    all_p_values(counter,:)=t_test;
    all_t_values(:,counter)=real_t;
    counter=counter+1;

    
end
end
%% Sum significance across all baselines (i.e. get how many times a point was sig)
sumed_all_p_values=sum(all_p_values, 1);
t_plot=[find(sumed_all_p_values);sumed_all_p_values(find(sumed_all_p_values))];
y=(max([-1*mean(erp(:,1:12),2)',-1*mean(erp(:,13:24),2)'])*1.07)*ones(length(t_plot(1,:)),1);

%% PLOT OVERALL RESULTS SIG
figure;
% blue is cued and orange is not cued
plot(-1*mean(erp(:,1:12),2)');
hold on;
plot(-1*mean(erp(:,13:24),2)');
hold on;
scatter(t_plot(1,:),y, 30,t_plot(2,:), '*')
        axis([410 1536 (min([-1*mean(erp(:,1:12),2)',-1*mean(erp(:,13:24),2)'])*1.23) (max([-1*mean(erp(:,1:12),2)',-1*mean(erp(:,13:24),2)'])*1.25)])
        set(gca,'Xtick',410:60:1536)
        set(gca,'XtickLabel',Time(410:60:1536))
%        set(gca,'YtickLabel',[1.5, 1, 0.5, 0, -0.5])


%% PLOT OVERALL RESULTS (each waveform)
figure
for p=1:length(easyoverall_erp(:,1))
    
    plot(easyoverall_erp(p,1:1536), 'Color',[1 0.6 0.78]);
    hold on;
    plot(hardoverall_erp(p,1:1536),'Color', [0.3 0.74 0.93]);
    hold on;
    
end
        axis([410 1536 (min([-1*mean(erp(:,1:12),2)',-1*mean(erp(:,13:24),2)'])*2) (max([-1*mean(erp(:,1:12),2)',-1*mean(erp(:,13:24),2)'])*1.5)])
        set(gca,'Xtick',410:60:1536)
        set(gca,'XtickLabel',Time(410:60:1536))

        
