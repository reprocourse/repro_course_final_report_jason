library(pwr)
library(ggplot2)

# effect sizes for t test run
#cohend=seq(0.2,1.6,0.1)

# For Balanced ONE-WAY-ANOVA Test
cohend=seq(0.1,0.8,0.05)
count=1
num_group=2
data=read.csv("/Users/jasondsc/Desktop/neur_602_paper/Raw_data/sample_sizes.csv")
sample_sizes=data$nsub_after_exc

sample_sizes=as.data.frame(sample_sizes)
ggplot(sample_sizes, aes(x=sample_sizes)) + 
  geom_histogram(aes(y=..density..),color="black", fill="pink", binwidth = 5, position = "identity") +geom_density(alpha=0.6, fill="pink") + xlab("Sample Size") + ylab("Number of Studies") + theme_minimal() + geom_vline(xintercept = median(sample_sizes[,1]), linetype="dashed", 
           color = "black", size=1)

# divide the number of sample per group if assuiming non paired test
#sample_sizes=sample_sizes/num_group

one_group=data.frame()

for (ds in cohend){

for (i in 1:length(sample_sizes[,1])){
  #power=pwr.t.test(n=sample_sizes[i,], sig.level = 0.05, d = ds, type = "paired")
  #power=pwr.t.test(n=sample_sizes[i,], sig.level = 0.05, d = ds, type = "two.sample")
  power=pwr.anova.test(k=num_group,n=sample_sizes[i,], sig.level = 0.05, f = ds)
  print(sample_sizes[i,])
  print(power$power)
  one_group[count,i]=power$power
}
  count=count+1
}   

porportion=seq(0,1,0.01)
porportions_bigger_than=data.frame()
for (k in 1:length(cohend))
for (j in 1:length(porportion)){
  
  jj=porportion[j]
  pro=mean(one_group[k,] > jj)
  porportions_bigger_than[k,j]=pro
}

power_plot=as.data.frame(t(rbind(porportion, porportions_bigger_than)))
colnames(power_plot)[1]= "power"

## FOR T-TEST EFFECT SIZES
# rr=rep(c(0.2,0.5,0.8,1.1,1.4),101)
# rr=rr[order(rr)]
# ploter=cbind(100*rep(porportion,5),rr, c(power_plot$V2 , power_plot$V5, power_plot$V8, power_plot$V11, power_plot$V14))
# ploter=as.data.frame(ploter)
# ploter$rr=as.factor(ploter$rr)

## FOR ANOVA EFFECT SIZES
rr=rep(c(0.1,0.2,0.3,0.4,0.5),101)
rr=rr[order(rr)]
ploter=cbind(100*rep(porportion,5),rr,c(power_plot$V2 , power_plot$V4, power_plot$V6, power_plot$V8, power_plot$V9))
ploter=as.data.frame(ploter)
ploter$rr=as.factor(ploter$rr)

ggplot(data=ploter, aes(x=V1, y=V3, colour=rr, group=rr)) +
  geom_line(size=1.3) + scale_fill_brewer(palette="Pastel1") + theme_minimal() + labs(y= "Porportion of Studies", x ="Power (%)", color= "Effect Size")  +
  coord_cartesian(ylim=c(0, 1)) + theme(legend.justification=c(1,1), legend.position=c(1,1)) + geom_vline(xintercept = 80, linetype="dashed", 
                                                                                                          color = "black", size=1)

