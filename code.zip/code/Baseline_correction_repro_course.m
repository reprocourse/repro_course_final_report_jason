
%%%%%%%%%%%%%%%%%%% SET PARAMETERS FOR THE CODE  %%%%%%%%%%%%%%%%%%%%%%%%%
cuepart=dir('/Users/jasondsc/Desktop/ERP_baseline_correction/cue/*.mat');
nocuepart=dir('/Users/jasondsc/Desktop/ERP_baseline_correction/nocue/*.mat');
electrodes=[13, 45, 53, 14, 19, 54, 12, 23, 55];
n_permutes = 5000;
alpha_level=0.05;
%% OCCIITAL BUNDLE
%16, 17, 18, 48, 49, 50, 51, 47, 20, 15
%% Parietal buncdle
% 13, 45, 53, 14, 19, 54, 12, 23, 55
nTimepoints=376;
npart=30;
trials=npart*2;
erp=zeros(nTimepoints,trials);
raw_eeg=zeros(nTimepoints,2*trials);
length_win=[25, 50, 63, 75, 100, 125];
counter=1;

%%%%%%%%%%%% READ DATA AND COMPURTE ERP  %%%%%%%%%%%%%%%%%%%
%%%%%CUE%%%%%%
cd('/Users/jasondsc/Desktop/ERP_baseline_correction/cue');
for i=1:trials
    load(cuepart(i,1).name);
    disp(cuepart(i,1).name)
    temp=F(electrodes,:);
    temp_1=squeeze(mean(temp,1))';
    raw_eeg(:,i)=temp_1;

end

%%%%%%% NO CUE %%%%%%%%%%
cd('/Users/jasondsc/Desktop/ERP_baseline_correction/nocue');
for i=1:trials
    load(nocuepart(i,1).name);
    disp(nocuepart(i,1).name)
    temp=F(electrodes,:);
    temp_1=squeeze(mean(temp,1))';
    raw_eeg(:,i+trials)=temp_1;

end

%%% COMPUTE ERP BY SUBTRACTING SEEN vs NOT SEEN
tftimes=Time;
erp=raw_eeg(:,2:2:120)-raw_eeg(:,1:2:120);

raw_eeg_orig=raw_eeg;
ms= (Time.*1000)+500;
ms(:,1)=1;

for j=1:length(length_win)

%%%% SET UP FOR PERMUTATIONS 
w=length_win(j);
L = 125;

for k1 = 1:L-w+1
    
baseline=k1:k1+w-1;
raw_eeg=raw_eeg_orig-mean(raw_eeg_orig(baseline,:));
erp=raw_eeg(:,2:2:120)-raw_eeg(:,1:2:120);

cued_overall_erp(counter,:)=-1*mean(erp(:,1:30),2)';
not_cued_overall_erp(counter,:)=-1*mean(erp(:,31:60),2)';

real_condition_mapping = [repmat(-1,1,npart), repmat(1,1,npart)];

% compute paired t-test for real data
dif = sum(erp(:,real_condition_mapping==-1)-erp(:,real_condition_mapping==1),2);
tnum = dif./sum(real_condition_mapping==-1);
sqdiff=sum((erp(:,real_condition_mapping==-1)-erp(:,real_condition_mapping==1).^2),2);
tdenom_n = sqdiff- ((dif.^2)./sum(real_condition_mapping==-1));
tdenom_d = (sum(real_condition_mapping==-1)-1)*sum(real_condition_mapping==-1);
tdenom = abs(sqrt(tdenom_n./tdenom_d));
real_t = tnum./tdenom;

% initialize null hypothesis matrices
permuted_tvals  = zeros(n_permutes,nTimepoints);

% generate null hypothesis parameter distributions
for permi = 1:n_permutes
    per=sign(randn(trials/2,1));
    fake_condition_mapping = [per; -per];
    
    % compute t-map of null hypothesis
    dif = sum(erp(:,fake_condition_mapping==-1)-erp(:,fake_condition_mapping==1),2);
    tnum = dif./sum(fake_condition_mapping==-1);
    sqdiff=sum((erp(:,fake_condition_mapping==-1)-erp(:,fake_condition_mapping==1).^2),2);
    tdenom_n = sqdiff- ((dif.^2)./sum(fake_condition_mapping==-1));
    tdenom_d = (sum(fake_condition_mapping==-1)-1)*sum(fake_condition_mapping==-1);
    tdenom = abs(sqrt(tdenom_n./tdenom_d));
    tmap = tnum./tdenom;
    
    % save all permuted values
    permuted_tvals(permi,:) = tmap;

end

%% GET PERCENTILE OF CRITICAL T VALUE TO COMPARE

crit_t=prctile(permuted_tvals,100*(1-(alpha_level/2)));

t_test= abs(real_t')>crit_t;

    all_p_values(counter,:)=t_test;
    all_t_values(:,counter)=real_t;
    counter=counter+1;

    
end
end
sumed_all_p_values=sum(all_p_values, 1);
t_plot=[find(sumed_all_p_values);sumed_all_p_values(find(sumed_all_p_values))];
y=(max([-1*mean(erp(:,1:30),2)',-1*mean(erp(:,31:60),2)'])*1.07)*ones(length(t_plot(1,:)),1);

figure;
%% PLOT DIFFERENCE WAVES TO VERIFY
% blue is cued and orange is not cued
plot(-1*mean(erp(:,1:30),2)');
hold on;
plot(-1*mean(erp(:,31:60),2)');
hold on;
scatter(t_plot(1,:),y, 30,t_plot(2,:), '*')
        axis([76 376 (min([-1*mean(erp(:,1:30),2)',-1*mean(erp(:,31:60),2)'])*1.23) (max([-1*mean(erp(:,1:30),2)',-1*mean(erp(:,31:60),2)'])*1.25)])
        set(gca,'Xtick',76:20:376)
        set(gca,'XtickLabel',Time(76:20:376))
%        set(gca,'YtickLabel',[1.5, 1, 0.5, 0, -0.5])



figure
for p=1:length(cued_overall_erp(:,1))
    
    plot(cued_overall_erp(p,76:376), 'Color',[1 0.6 0.78]);
    hold on;
    plot(not_cued_overall_erp(p,76:376),'Color', [0.3 0.74 0.93]);
    hold on;
    
end
        axis([1 301 (min([-1*mean(erp(:,1:30),2)',-1*mean(erp(:,31:60),2)'])*1.23) (max([-1*mean(erp(:,1:30),2)',-1*mean(erp(:,31:60),2)'])*1.25)])
        set(gca,'Xtick',1:20:301)
        set(gca,'XtickLabel',Time(76:20:376))

% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%% EXTRACT VALUES FOR REGRESSION %%%%%%%%%%%%%%%%%%%%%%%%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %% change the significant time based on results to run regression analysis
% % VAN -- 110 -115
% % P300 -- 124-150
% sigtimes= 110:115;
% data_export=zeros(npart,2);
% 
% for i=1:npart
%     values=mean(erp(sigtimes,i))-mean(erp(sigtimes,i+30));
%     data_export(i,1)=i;
%     data_export(i,2)=values;
% 
% end
% 
% csvwrite("~/Desktop/VAN_export.csv", data_export);