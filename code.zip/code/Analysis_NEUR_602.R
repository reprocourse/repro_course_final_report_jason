


papers=read.csv("~/Desktop/neur_602_paper/pubmed_result.csv")
indx=runif(50,1,1075)

papers_intrest=papers[indx,]

write.csv(papers_intrest, "~/Desktop/neur_602_paper/rand_selected.csv", row.names = FALSE)

